//
//  ResultViewController.swift
//  Bucks
//
//  Created by Ogunsola, Damilola Olapeju on 11/21/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var Income: UILabel!
    
    @IBOutlet weak var withheld: UILabel!
    
    @IBOutlet weak var refundAmount: UILabel!
    
    @IBOutlet weak var Rate: UILabel!
    
    @IBOutlet weak var resultView: UITextView!
    
    var taxRate = 0.0
    var incomeTotal = 0.0
    var withheldIncome = 0.0
    var remainder = 0.0
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        Income.text = String(incomeTotal)
        withheld.text = String(withheldIncome)
        Rate.text = String(taxRate) + " " + "%"
        let percentageRate = taxRate/100
        let taxableIncome = percentageRate * incomeTotal
        
        if taxableIncome > withheldIncome {
            remainder = taxableIncome - withheldIncome
            refundAmount.text = String(format: "%.2f", remainder)
            resultView.text = "Your tax refund amount is \(String(format: "%.2f", remainder)). You may owe owe some money to the IRS. Please speak to your tax officer on steps forward."
        }
        else if withheldIncome > taxableIncome {
            remainder = withheldIncome - taxableIncome
            refundAmount.text = String(format: "%.2f", remainder)
            resultView.text = "Your tax refund amount is \(String(format: "%.2f", remainder)). You may be eligible for some refund from the IRS. Please speak to your tax officer on steps forward."
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
