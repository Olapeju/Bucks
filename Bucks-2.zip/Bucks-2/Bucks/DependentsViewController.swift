//
//  DependentsViewController.swift
//  Bucks
//
//  Created by Choday, Atchyutha Veni on 10/1/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class DependentsViewController: UIViewController {

    @IBOutlet weak var Dlabel1: UILabel!
    
    @IBOutlet weak var NumOfDependents: UITextField!
    
    @IBOutlet weak var Dlabel2: UILabel!
    
    @IBOutlet weak var AgeOfDependents: UITextField!
    
    
    var status = ""
    var status1 = ""
    
    @IBAction func SegmentedControl(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Dlabel1.isHidden = false
            Dlabel2.isHidden = false
            NumOfDependents.isHidden = false
            AgeOfDependents.isHidden = false
        }
        else {
            Dlabel1.isHidden = true
            Dlabel2.isHidden = true
            NumOfDependents.isHidden = true
            AgeOfDependents.isHidden = true
        }
    }
    
    @IBAction func Next(_ sender: UIButton) {
        self.status1 = status
        performSegue(withIdentifier: "Depends", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! IncomeViewController
        
        vc.status = self.status1
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Dlabel1.isHidden = true
        Dlabel2.isHidden = true
        NumOfDependents.isHidden = true
        AgeOfDependents.isHidden = true

    
    }
    

    
   
}
