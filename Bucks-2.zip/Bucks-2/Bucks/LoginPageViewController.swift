//
//  LoginPageViewController.swift
//  Bucks
//
//  Created by Ogunsola, Damilola Olapeju on 12/7/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class LoginPageViewController: UIViewController {
    
    @IBOutlet weak var email: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    
    
    @IBAction func login(_ sender: Any) {
        let userEmail = email.text
        let userpassword = password.text
        
        
        
        //check for empty field
        if (userEmail!.isEmpty || userpassword!.isEmpty)
        {
            displayAlertMessage(userMessage: "All fields are required")
            return
        }
        else{
            self.performSegue(withIdentifier: "Login2Home", sender: self)
            
        }
        
    }
    
    
    func displayAlertMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        myAlert.addAction(action)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        email.placeholder = "Enter your email address"
        password.placeholder = "Enter your password"

        // Do any additional setup after loading the view.
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
        email.placeholder = ""
        password.placeholder = ""
        return true
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
