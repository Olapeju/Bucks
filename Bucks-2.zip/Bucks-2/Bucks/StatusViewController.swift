//
//  StatusViewController.swift
//  Bucks
//
//  Created by Choday, Atchyutha Veni on 10/1/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class StatusViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{

    let pickItem = ["Single", "Head of House", "Qualified widower", "Married filing seperately","Married filing jointly"]
    var status = ""
    var selected = ""
    
    
    @IBOutlet weak var AgeOfSpouse: UILabel!
    
    @IBOutlet weak var AgeSpouseField: UITextField!
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    @IBAction func Next1(_ sender: UIButton) {
        
        //performSegue(withIdentifier:"DependSegue", sender: self)
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickItem[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickItem.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selected = pickItem[row]
        
        if pickItem[row] == "Married filing jointly" {
            AgeOfSpouse.isHidden = false
            AgeSpouseField.isHidden = false
        }
        else {
            AgeOfSpouse.isHidden = true
            AgeSpouseField.isHidden = true

        }
    }
    
    
    @IBAction func Next(_ sender: UIButton) {
        self.status = selected
        performSegue(withIdentifier: "Status", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! DependentsViewController
        
        vc.status = self.status
    }
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        AgeOfSpouse.isHidden = true
        AgeSpouseField.isHidden = true
        selected = pickItem[0]

        
    }
 
    

    

}
