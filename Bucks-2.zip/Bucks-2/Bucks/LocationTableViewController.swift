//
//  LocationTableViewController.swift
//  Bucks
//
//  Created by Ogunsola, Damilola Olapeju on 12/6/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class LocationTableViewController: UITableViewController {
    var location = ["Liberty Tax services", "Jackson Hewith Tax services", "Padgett Business services", "H&R Block", "Credit central", "Tax preofessional Inc", "Onestop Tax"]
    var address = ["15618 TX-3, webster, TX, 77598", "6829 Spencer Hwy, Pasadena, TX, 77505", "16872 Royal crest Dr, Houston, TX, 77058", "14624 woodforest Blvd, Houston, TX, 77015", "3604 Fairmont pkwy, pasadena, TX, 77504","3650 old chocolate Bayou Rd, manvel, TX, 77578","16 uvalde Rd, Houston, TX, 77015"]

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return location.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = location[indexPath.row]
        cell.detailTextLabel?.text = address[indexPath.row]
        return cell
    }

    
}
