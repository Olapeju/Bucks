//
//  TableViewController.swift
//  Bucks
//
//  Created by Ogunsola, Damilola Olapeju on 9/25/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit
var content = ["News update", "Login/Register", "Tax return", "Find Location", "Help section" ]
var myIndex = 0
var id = ["NewsUpdate", "Login", "TaxReturn", "Location", "Help"]
class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  content.count
    }

    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = content[indexPath.row]
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //performSegue(withIdentifier: id[indexPath], sender: self)
        myIndex = indexPath.row
        switch myIndex {
        case 0:
            performSegue(withIdentifier: "NewsUpdate", sender: self)
        case 1:
            performSegue(withIdentifier: "Login", sender: self)
        case 2:
            performSegue(withIdentifier: "TaxReturn", sender: self)
        case 3:
            performSegue(withIdentifier: "Location", sender: self)
        case 4:
            performSegue(withIdentifier: "Help", sender: self)
        default:
            print("index")
        }
    }
    
}
