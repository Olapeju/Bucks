//
//  IncomeViewController.swift
//  Bucks
//
//  Created by Choday, Atchyutha Veni on 10/1/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class IncomeViewController: UIViewController {
    
    @IBOutlet weak var ButtonTax: UIButton!
    
    @IBOutlet weak var TotalTax: UILabel!
    
    @IBOutlet weak var Ilabel1: UITextField!
    
    @IBOutlet weak var wages: UISegmentedControl!
    
    @IBOutlet weak var Ilabel2: UITextField!
    
    
    @IBOutlet weak var Ilabel3: UITextField!
    
    
    @IBOutlet weak var Ilabel4: UITextField!
    

    @IBOutlet weak var Ilabel5: UITextField!
    
    
    @IBOutlet weak var Ilabel6: UITextField!
    
    
    @IBOutlet weak var Ilabel7: UITextField!
    
    
    @IBOutlet weak var Ilabel8: UITextField!
    
    
    @IBOutlet weak var Totallabel: UITextField!
    
    @IBOutlet weak var DollarLabel: UILabel!
    
    @IBOutlet weak var DollarLabel2: UILabel!
    
    
    @IBOutlet weak var DollarLabel3: UILabel!
    
    @IBOutlet weak var DollarLabel4: UILabel!
    
    @IBOutlet weak var DollarLabel5: UILabel!
    
    
    @IBOutlet weak var DollarLabel6: UILabel!
    
    @IBOutlet weak var DollarLabel7: UILabel!
    
    @IBOutlet weak var DollarLabel8: UILabel!
    
    var status = ""
    var status1 = ""
    var total = 0.0
    
    
    @IBAction func WagesSeg(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
            Ilabel1.isHidden = false
            DollarLabel.isHidden = false
            
        }
         else {
            
            Ilabel1.isHidden = true
            DollarLabel.isHidden = true
        
        }
    }
    
    
    @IBAction func InterestSeg(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Ilabel2.isHidden = false
            DollarLabel2.isHidden = false
        }
        else {
            Ilabel1.isHidden = true
            DollarLabel2.isHidden = true
        }
        
    }
    
    
    @IBAction func RetireSeg(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Ilabel3.isHidden = false
            DollarLabel3.isHidden = false
        }
        else {
            Ilabel3.isHidden = true
            DollarLabel3.isHidden = true
        }
    }
    
    
    @IBAction func EmploymentSeg(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Ilabel4.isHidden = false
            DollarLabel4.isHidden = false
        }
        else {
            Ilabel4.isHidden = true
            DollarLabel4.isHidden = true
        }
    }
    
    
    @IBAction func RentalSeg(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Ilabel5.isHidden = false
            DollarLabel5.isHidden = false
        }
        else {
            Ilabel5.isHidden = true
            DollarLabel5.isHidden = true
        }
    }
    
    
    @IBAction func UnemploySeg(_ sender: UISegmentedControl) {
       
        if sender.selectedSegmentIndex == 0 {
            Ilabel6.isHidden = false
            DollarLabel6.isHidden = false
        }
        else {
            Ilabel6.isHidden = true
            DollarLabel6.isHidden = true
        }
    }
    
    
    @IBAction func CaptialSeg(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Ilabel7.isHidden = false
            DollarLabel7.isHidden = false
        }
        else {
            Ilabel7.isHidden = true
            DollarLabel7.isHidden = true
        }
    }
    
    
    @IBAction func OtherIncomeSeg(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            Ilabel8.isHidden = false
            DollarLabel8.isHidden = false
        }
        else {
            Ilabel8.isHidden = true
            DollarLabel8.isHidden = true
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        

        Ilabel1.isHidden = true
        Ilabel2.isHidden = true
        Ilabel3.isHidden = true
        Ilabel4.isHidden = true
        Ilabel5.isHidden = true
        Ilabel6.isHidden = true
        Ilabel7.isHidden = true
        Ilabel8.isHidden = true
       
        
        DollarLabel.isHidden = true
        DollarLabel2.isHidden = true
        DollarLabel3.isHidden = true
        DollarLabel4.isHidden = true
        DollarLabel5.isHidden = true
        DollarLabel6.isHidden = true
        DollarLabel7.isHidden = true
        DollarLabel8.isHidden = true
        
        
  
    }
    
    @IBAction func TaxTotal(_ sender: Any) {
        let Wage = Double(Ilabel1.text!);
        let Interest = Double(Ilabel2.text!);
        let Retirements = Double(Ilabel3.text!);
        let Employment = Double(Ilabel4.text!);
        let Rental = Double(Ilabel5.text!);
        let Unemployment = Double(Ilabel6.text!);
        let Capital = Double(Ilabel7.text!);
        let Other = Double(Ilabel8.text!);
        
        let OutputTax = Double(Wage!+Interest!+Retirements!+Employment!+Rental!+Unemployment!+Capital!+Other!)
        TotalTax.text = "\(OutputTax)"
        
    }
    
    
    
    @IBAction func next(_ sender: UIButton) {
        self.total = Double(TotalTax.text!)!
        self.status1 = status
        performSegue(withIdentifier: "Withhold", sender: self)
        
    }
    
   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! WithholdingsViewController
        
        vc.status = self.status1
        vc.Total = self.total
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
