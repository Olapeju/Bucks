//
//  SignUpViewController.swift
//  Bucks
//
//  Created by Ogunsola, Damilola Olapeju on 12/7/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    
    
    @IBOutlet weak var email: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    
    @IBOutlet weak var passwordConfirm: UITextField!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        email.placeholder = "Enter your email address"
        password.placeholder = "Enter your password"
        passwordConfirm.placeholder = "Retype your password"


        // Do any additional setup after loading the view.
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
        email.placeholder = ""
        password.placeholder = ""
        passwordConfirm.placeholder = ""
        return true
    }
    
    
    func displayAlertMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        myAlert.addAction(action)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func signUpAction(_ sender: Any) {
        
        let userEmail = email.text
        let userpassword = password.text
        let confirm = passwordConfirm.text
        
        
        //check for empty field
        if (userEmail!.isEmpty || userpassword!.isEmpty || confirm!.isEmpty)
        {
            displayAlertMessage(userMessage: "All fields are required")
            return
        }
        else if (userpassword != confirm){
            displayAlertMessage(userMessage: "Passwords do not match")
            return
            
        }
        else{
            self.performSegue(withIdentifier: "Signup2Home", sender: self)
        }
        
        
        //store data
//        UserDefaults.resetStandardUserDefaults().setObject(userEmail, value(forKey: "userEmail"))
        
    }
    
    
    


}



//        if password.text != passwordConfirm.text {
//            let alertController = UIAlertController(title: "Password Incorrect", message: "Please re-type password", preferredStyle: .alert)
//            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//
//            alertController.addAction(defaultAction)
//            self.present(alertController, animated: true, completion: nil)
//        }
//        else{
//            //Auth.auth().createUser(withEmail: email.text!, password: password.text!){ (user, error) in
//                if error == nil {
//                    self.performSegue(withIdentifier: "signupToHome", sender: self)
//                }
//                else{
//                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
//                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//
//                    alertController.addAction(defaultAction)
//                    self.present(alertController, animated: true, completion: nil)
//                }
//            }
//        }
//    }

/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destination.
 // Pass the selected object to the new view controller.
 }
 */
