//
//  ViewController.swift
//  Bucks
//
//  Created by Ogunsola, Damilola Olapeju on 9/23/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

