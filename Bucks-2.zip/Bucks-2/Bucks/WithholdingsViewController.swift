//
//  Withholdings.swift
//  Bucks
//
//  Created by Choday, Atchyutha Veni on 11/5/18.
//  Copyright © 2018 Ogunsola, Damilola Olapeju. All rights reserved.
//

import UIKit

class WithholdingsViewController: UIViewController {

    @IBOutlet weak var Y4: UISegmentedControl!
    @IBOutlet weak var Y3: UISegmentedControl!
    @IBOutlet weak var Y2: UISegmentedControl!
    @IBOutlet weak var Y1: UISegmentedControl!
    @IBOutlet weak var W4: UILabel!
    @IBOutlet weak var W3: UILabel!
    @IBOutlet weak var W2: UILabel!
    @IBOutlet weak var W1: UILabel!
    @IBOutlet weak var HeldTotal: UITextField!
    @IBOutlet weak var D4: UILabel!
    @IBOutlet weak var D3: UILabel!
    @IBOutlet weak var D2: UILabel!
    @IBOutlet weak var D1: UILabel!
    @IBOutlet weak var Held3: UITextField!
    @IBOutlet weak var Held2: UITextField!
    @IBOutlet weak var Held1: UITextField!
    
    @IBOutlet weak var TotalWithheld: UILabel!
    
    
    var status = ""
    var Total = 0.0
    var Total1 = 0.0
    var totalWithheld = 0.0
    var withheldTotal = 0.0
    var rate = 0.0
    var taxRate = 0
    var with = 0.0
    
    @IBAction func Withheld1(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
            
            
            W2.isHidden = false
            W3.isHidden = false
            W4.isHidden = false
            Y2.isHidden = false
            Y3.isHidden = false
            Y4.isHidden = false
            
        }
        else{
         
            
            Y2.isHidden = true
            
            Y3.isHidden = true
            
            W2.isHidden = true
            W3.isHidden = true
            W4.isHidden = true
            Y4.isHidden = true
        }
        
    }
    
    @IBAction func Withheld2(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
            Held1.isHidden = false
            D1.isHidden = false
        }
        else {
            Held1.isHidden = true
            D1.isHidden = true
        }
    }
    @IBAction func Withheld3(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
            Held2.isHidden = false
            D2.isHidden = false
        }
        else {
            Held2.isHidden = true
            D2.isHidden = true
        }
    }
    @IBAction func Withheld4(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
            Held3.isHidden = false
            D3.isHidden = false
        }
        else {
            Held3.isHidden = true
            D3.isHidden = true
        }
    }
    
    @IBAction func TotalButton(_ sender: Any) {
        
        let w2 = Double(Held1.text!);
        let over = Double(Held2.text!);
        let otherw = Double(Held3.text!);
        let Total7 = Double(w2!+over!+otherw!)
        TotalWithheld.text = "\(Total7)"
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        rate = Rate()
        Held1.isHidden = true
        D1.isHidden = true
        Held2.isHidden = true
        D2.isHidden = true
        Held3.isHidden = true
        D3.isHidden = true
        W2.isHidden = true
        W3.isHidden = true
        W4.isHidden = true
        Y2.isHidden = true
        Y3.isHidden = true
        Y4.isHidden = true
    }
    
    
    
    
    func Rate() -> Double {
        if (status == "Single") && (Total >= 1.0 && Total <= 9525.0)
        {
            rate = 10.0
        }
        else if (status == "Married filing jointly") || (status == "Qualified widower") && (Total >= 1.0 && Total <= 19050.0)
        {
                rate = 10.0
        }
        else if (status == "Married filing seperately") && (Total >= 1.0 && Total <= 9525.0)
        {
            rate = 10.0
        }
        else if (status == "Head of house") && (Total >= 1.0 && Total <= 13600.0)
        {
            rate = 10.0
        }
        else if (status == "Single") && (Total >= 9526.0 && Total <= 38700.0)
        {
            rate = 12.0
        }
        else if (status == "Married filing jointly") || (status == "Qualified widower") && (Total >= 19051.0 && Total <= 77400.0)
        {
            rate = 12.0
        }
        else if (status == "Married filing seperately") && (Total >= 9526.0 && Total <= 38700.0)
        {
            rate = 12.0
        }
        else if (status == "Head of house") && (Total >= 13601.0 && Total <= 51800.0)
        {
            rate = 12.0
        }
        else if (status == "Single") && (Total >= 38701.0 && Total <= 82500.0)
        {
            rate = 22.0
        }
        else if (status == "Married filing jointly") || (status == "Qualified widower") && (Total >= 77401.0 && Total <= 165000.0)
        {
            rate = 22.0
        }
        else if (status == "Married filing seperately") && (Total >= 38701.0 && Total <= 82000.0)
        {
            rate = 22.0
        }
        else if (status == "Head of house") && (Total >= 51801.0 && Total <= 82500.0)
        {
            rate = 22.0
        }
        
        return rate
    }

    
    
    @IBAction func Next(_ sender: Any) {
        self.Total1 = Total
        self.rate = Rate()
        
        let w2 = Double(Held1.text!);
        let over = Double(Held2.text!);
        let otherw = Double(Held3.text!);
        let Total7 = Double(w2!+over!+otherw!)
        TotalWithheld.text = "\(Total7)"
        
//        var with = Double(TotalWithheld.text)
        self.withheldTotal = Double(w2!+over!+otherw!)
//        Double(TotalWithheld.text) = self.withheldTotal
        performSegue(withIdentifier: "Result", sender: self)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ResultViewController
        
        vc.taxRate = self.rate
        vc.incomeTotal = self.Total1
        vc.withheldIncome = self.withheldTotal
        
        
    }
    
    
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


